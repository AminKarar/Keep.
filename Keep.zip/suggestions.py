# import financial_data
# from flask import request
# from flask import Flask
# from flask import render_template
# import app

# financial_values = financial_data.financial_values

# form = request.form
# sales = form["sales"] #REVENUE = SALES
# sales = int(sales)
# cogs = form["cogs"]
# cogs = int(cogs)
# operatingexpenses = form["operatingexpenses"] 
# depamor = form["depamor"]
# ebit = form["ebit"] # Interest expense - taxes 
# operatingexpenses = int(operatingexpenses)
# depamor = int(depamor)
# ebit = int(ebit)

# # --- MATH FROM APP ---
# grossprofit = sales - cogs
# operatingprofit = sales - cogs - operatingexpenses - depamor
# netprofit = operatingprofit - ebit
# # --- MATH FROM APP ---

# # --- LOGIC FOR SUGGESTIONS WITH LINKS 


# lossadvice = "It looks like you're current running in a loss. No worries try some of our resources."
# link1 = "https://www.forbes.com/sites/mikekappel/2017/05/03/5-causes-for-a-small-business-losing-money/"
# link2 = "https://www.prospa.com/blog/5-ways-stop-your-business-losing-money"
# link3 = "https://www.consultstraza.com/5-ways-your-small-business-may-be-losing-money-and-how-to-stop-it/"

# stagnantadvice = "You're on the right track! Here are some resources that'll help your growth."
# link4 = "https://smallbiztrends.com/2018/04/how-to-grow-your-small-business.html"
# link5 = "https://www.nytimes.com/guides/business/how-to-grow-your-business"
# link6 = "https://www.entrepreneur.com/article/306049"

# growthadvice = "It looks like you're growing quickly! Here are some articles to maintain that growth."
# link7 = "https://www.forbes.com/sites/glennllopis/2015/09/29/top-6-ways-to-sustain-business-growth/"
# link8 = "https://www.bdc.ca/en/articles-tools/business-strategy-planning/manage-growth/9-tips-handling-fast-business-growth"
# link9 = "https://hbr.org/1983/05/the-five-stages-of-small-business-growth"

# @app.route('/myFinances', methods=["POST"])
# def determine_links():
# # DETERMINE THE LINKS AND ADVICE BASED ON THE CURRENT GROWTH!!
#   if netprofit <= 0:
#     advice = lossadvice
#   elif netprofit * 1.05 >= financial_values[4]["net_profit"]: 
#     link1 = link7
#     link2 = link8
#     link3 = link9
#     advice = growthadvice
#   elif financial_values[4]*0.95 <= netprofit < financial_values[4]*1.05: 
#     link1 = link4
#     link2 = link5
#     link3 = link6
#     advice = stagnantadvice
#   else: 
#     link1 = link4
#     link2 = link5
#     link3 = link6
#     advice = stagnantadvice
    


#

   
    
    